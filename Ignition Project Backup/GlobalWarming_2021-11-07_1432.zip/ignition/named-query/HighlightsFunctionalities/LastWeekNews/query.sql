exec lastWeekNews @Country = :Country, @City = :City, @EndDate = :EndDate
