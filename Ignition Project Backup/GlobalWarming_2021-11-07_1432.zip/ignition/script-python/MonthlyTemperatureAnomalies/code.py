def get_color(value):
	min = -6.24
	max = 3.24
	
	colors = ['#034799', '#0e57b0', '#317cd6', '#5799eb', '#9ac3f5', '#e6effa',  '#fcf5e1',  '#e6effa']
	reds = ['#fcd9d9', '#f5c4c4', '#f58989', '#ed5a5a', '#cf1f1f', '#b80000', '#b80000']
	
	color = ''
	
	if value > max:
		color = '#ab0a0a'
	elif value < min:
		color = '#02245c'
	elif value < 0:
		i = 0
		while min < 0:
			if value > min and value <= (min + 1):
				color = colors[i]
			min = min + 1
			i = i + 1
	elif value >= 0:
		min = 0.76
		i = 0
		while min <= max:
			if value > min and value <= min + 0.5:
				color = reds[i]
			min = min + 0.5		
			i = i + 1	
	return color
	
	
def get_scale():
	min = -6.24
	max = 3.24
	
	colors = ['#034799', '#0e57b0', '#317cd6', '#5799eb', '#9ac3f5', '#e6effa',  '#fcf5e1',  '#e6effa']
	reds = ['#fcd9d9', '#f5c4c4', '#f58989', '#ed5a5a', '#cf1f1f', '#b80000', '#b80000']
	values = []
	dict = {}
	dict['color'] = '#02245c'
	dict['label'] = '< ' + str(min)
	values.append(dict)	
	

	i = 0
	while min < 0:
		dict = {}
		dict['color'] = colors[i]
		dict['label'] = str(min) + ' to ' + str(min + 1)
		values.append(dict)
		min = min + 1
		i = i + 1
	min = 0.76
	i = 0
	while min <= max:
		dict = {}
		dict['color'] = reds[i]
		dict['label'] = str(min) + ' to ' + str(min +0.5)
		values.append(dict)
		min = min + 0.5
		i = i + 1

	dict = {}
	dict['color'] = '#ab0a0a'
	dict['label'] = '> ' + str(max)
	values.append(dict)		


	return values
	
	
def global_month_showcase():
	colors = ['#034799', '#0e57b0', '#317cd6', '#5799eb', '#9ac3f5', '#e6effa', '#fcd9d9', '#f5c4c4', '#f58989', '#ed5a5a', '#cf1f1f', '#b80000' ]
	months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
	
	values = []
	for i, j in zip(colors, months):
		dict = {}
		dict['color'] = i
		dict['name'] = j
		dict['value'] = 1
		values.append(dict)
		
	return values
		
