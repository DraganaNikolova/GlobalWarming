import system
import string

def getData(city, day):
	
	'''This function gets a JSON object from a weather forecast API and returns a dictionary for getting
	average temperature for particular day and city. Day needs to be in format yyyy-mm-dd
	It is beeing called from a Timer Gateway Event Script'''
	
	import json
	import string
	
	city = string.replace(city, ' ', '-')
	city = string.replace(city, 'é', 'e')
	city = string.replace(city, 'Ü', 'U')
	city = string.replace(city, 'ü', 'u')
	city = string.replace(city, 'á', 'a')
	city = string.replace(city, 'ó', 'o')
	city = string.replace(city, 'ã', 'a')
	city = string.replace(city, 'ê', 'e')
	city = string.replace(city, 'í', 'i')
	city = string.replace(city, 'ç', 'c')
	city = string.replace(city, 'Ö', 'O')
	city = string.replace(city, 'ë', 'e')
	city = string.replace(city, 'ú', 'u')
	
	namedQuery = "GetApiKey"	
	parameters={}
	key = system.db.runNamedQuery(project="GlobalWarming", path=namedQuery, parameters=parameters).getValueAt(0,0)
	
	exampleUrl="http://api.weatherapi.com/v1/history.json?key=e33dcb5f39db41c49b4121147213009&q=Skopje&dt=2021-09-29"
		
	url = "http://api.weatherapi.com/v1/history.json?key=" + key + "&q=" + city + "&dt=" + day
	
	try:
		data = system.net.httpGet(url=url)
		jsonData = system.util.jsonDecode(data)
		return get_temperature(city, day, jsonData)		
	except:
		system.util.getLogger("Gateway Timer Script").info("City Passed " + city)
		pass
	
	
def get_temperature(city, day, jsonData):
	
	''' This function goes through the dictionary and gets the values from the right keys: avgtemp_c
	It inserts the values in the database.'''

	temperature = 0
	minimum = 0
	maximum = 0
	icon = ''
	for key, value in jsonData.items():
		if type(value) is dict and key == 'forecast':
			for key2, value2 in value.items():		
				if key2 == 'forecastday':
					for key3, value3 in value2[0].items():
						if type(value3) is dict and key3 == 'day':
							for key4, value4 in value3.items():
								if key4 == 'avgtemp_c':
									temperature = value4
								elif key4 == 'mintemp_c':
									minimum = value4
								elif key4 == 'maxtemp_c':
									maximum = value4
								elif key4 == 'condition' and type(value4) is dict:
									for key5, value5 in value4.items():
										if key5 == 'icon':
											icon = value5

	# Insert temperature into database
	namedQuery = "InsertTemperature"
	parameters={"Day":day, "City":city, "Temperature":temperature, 'Minimum':minimum, "Maximum":maximum, "Icon":icon}
	system.db.runNamedQuery(project="GlobalWarming", path=namedQuery, parameters=parameters)
	
	#system.util.getLogger("Gateway Timer Script").info("Temperature, Minimum, Maximum " + str(temperature) + ', ' + str(minimum) + ', ' +str(maximum) )



   
	
