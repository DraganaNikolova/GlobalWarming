exec maxAnomalyPerYear @Country = :Country, @City = :City, @StartDate = :StartDate, @EndDate = :EndDate

