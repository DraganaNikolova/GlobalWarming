exec differenceLastWeek @Country = :Country, @City = :City, @EndDate = :EndDate

