exec warmestDecade @Country = :Country, @City = :City;
