def get_color(value):
	min = -6.24
	max = 3.24
	
	colors = ['#034799', '#0e57b0', '#317cd6', '#5799eb', '#9ac3f5', '#e6effa',  '#e6effa',  '#e6effa']
	reds = ['#fcf5e1', '#edc9b4', '#f58989', '#ed5a5a', '#cf1f1f', '#b80000', '#b80000',  '#e6effa']
	
	color = ''
	
	if value > max:
		color = reds[len(reds)-1]
	elif value < min:
		color = colors[0]
	elif value < 0:
		i = 0
		while min < 0:
			if value > min and value <= (min + 1):
				color = colors[i]
			min = min + 1
			i = i + 1
	elif value >= 0:
		min = 0
		i = 0
		while min <= max:
			if value > min and value <= min + 0.5:
				color = reds[i]
			min = min + 0.5		
			i = i + 1	
	return color
	
	
def get_scale():
	min = -6.24
	max = 3.24
	
	colors = ['#034799', '#0e57b0', '#317cd6', '#5799eb', '#9ac3f5', '#e6effa',  '#e6effa',  '#e6effa']
	reds = ['#fcf5e1', '#edc9b4', '#f58989', '#ed5a5a', '#cf1f1f', '#b80000', '#b80000',  '#e6effa']
	
	values = []
	dict = {}
	dict['color'] = reds[len(reds)-1]
	dict['label'] = '> ' + str(max)
	values.append(dict)

	i = 0
	while min < 0:
		dict = {}
		dict['color'] = colors[i]
		dict['label'] = str(min) + ' to ' + str(min + 1)
		values.append(dict)
		min = min + 1
		i = i + 1
	min = 0
	i = 0
	while min <= max:
		dict = {}
		dict['color'] = reds[i]
		dict['label'] = str(min) + ' to ' + str(min +0.5)
		values.append(dict)
		min = min + 0.5
		i = i + 1
			
	dict = {}
	dict['color'] = colors[0]
	dict['label'] = '< ' + str(min)
	values.append(dict)	
	return values
	
