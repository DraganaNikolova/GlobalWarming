exec gatherTemperatureForCity @Country = :Country, @City = :City;
