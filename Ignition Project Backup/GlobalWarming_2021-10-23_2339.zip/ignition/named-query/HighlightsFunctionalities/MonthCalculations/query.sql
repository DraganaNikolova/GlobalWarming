exec monthCalculations @Country = :Country, @City = :City, @Functionality = :Functionality
